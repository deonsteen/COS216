// Names: MAHIKA, DEON, TAUHIR
// Surnames: LALA, STEENKAMP, SEPTEMBER
// Student Numbers: 25013727, 25135742, 24750982

import { Injectable } from '@angular/core';
import { Subject, BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class WebsocketService {
    private ws: WebSocket | null = null;

    messages$ = new Subject<any>();
    connected$ = new BehaviorSubject<boolean>(false);

    connect(port: number): void {
        const url = `ws://localhost:${port}`;
        this.ws = new WebSocket(url);

        this.ws.onopen = () => {
            this.connected$.next(true);
            console.log('[WS] Connected to', url);
        };

        this.ws.onmessage = (event) => {
            try {
                const msg = JSON.parse(event.data);
                this.messages$.next(msg);
            } catch {
                console.error('[WS] Could not parse message:', event.data);
            }
        };

        this.ws.onclose = () => {
            this.connected$.next(false);
            console.log('[WS] Disconnected.');
        };

        this.ws.onerror = (err) => {
            console.error('[WS] Error:', err);
            this.connected$.next(false);
        };
    }

    send(obj: any): void {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify(obj));
        } else {
            console.warn('[WS] Cannot send — not connected.');
        }
    }

    disconnect(): void {
        this.ws?.close();
        this.ws = null;
    }
}