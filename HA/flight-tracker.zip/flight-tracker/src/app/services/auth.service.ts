// Names: MAHIKA, DEON, TAUHIR
// Surnames: LALA, STEENKAMP, SEPTEMBER
// Student Numbers: 25013727, 25135742, 24750982

import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface User {
    apikey: string;
    name: string;
    surname: string;
    email: string;
    type: 'Passenger' | 'ATC';
    username: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
    private API = 'https://u25013727:Elephant%40130206@wheatley.cs.up.ac.za/u25013727/api.php';

    currentUser$ = new BehaviorSubject<User | null>(null);

    get user(): User | null { return this.currentUser$.value; }

    async login(email: string, password: string): Promise<User> {
        const res = await fetch(this.API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: 'Login', email, password })
        });
        const json = await res.json();
        if (json.status !== 'success') throw new Error(json.data || 'Login failed');

        const d = json.data[0];
        const user: User = {
            apikey: d.apikey,
            name: d.name,
            surname: d.surname,
            email: d.email,
            type: d.type,
            username: d.name + '_' + d.surname
        };
        this.currentUser$.next(user);
        return user;
    }

    logout(): void {
        this.currentUser$.next(null);
    }
}