// Names: MAHIKA, DEON, TAUHIR
// Surnames: LALA, STEENKAMP, SEPTEMBER
// Student Numbers: 25013727, 25135742, 24750982

import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { WebsocketService } from '../../services/websocket.service';

@Component({
    selector: 'app-atc-dashboard',
    templateUrl: './atc-dashboard.component.html',
    styleUrls: ['./atc-dashboard.component.css']
})
export class AtcDashboardComponent implements OnInit, OnDestroy {
    flights: any[] = [];
    airports: any[] = [];
    selectedFlight: any = null;
    flightDetail: any = null;
    position: any = null;
    notifications: string[] = [];
    error = '';
    connected = false;

    private API = 'https://u25013727:Elephant%40130206@wheatley.cs.up.ac.za/u25013727/api.php';
    private sub!: Subscription;
    private connSub!: Subscription;

    constructor(public auth: AuthService, private ws: WebsocketService) { }

    ngOnInit(): void {
        this.connSub = this.ws.connected$.subscribe(c => { this.connected = c; });
        this.sub = this.ws.messages$.subscribe(msg => this.handleMessage(msg));
        this.loadFlights();
        this.loadAirports();
    }

    private handleMessage(msg: any): void {
        switch (msg.type) {
            case 'DISPATCH_OK':
                this.addNotification(`✅ Dispatched: ${msg.flight_number}`);
                this.loadFlights();
                break;
            case 'PASSENGER_BOARDED':
                this.addNotification(`✔ ${msg.username} confirmed boarding on flight ${msg.flight_id}`);
                this.refreshDetail();
                break;
            case 'PASSENGER_NO_SHOW':
                this.addNotification(`❌ ${msg.username} missed boarding on flight ${msg.flight_id}`);
                break;
            case 'POSITION':
                this.position = msg;
                break;
            case 'TRACK_OK':
                this.addNotification(msg.message);
                break;
            case 'FLIGHT_LANDED':
                this.addNotification(`🛬 ${msg.flight_number} has landed!`);
                this.position = null;
                this.loadFlights();
                break;
            case 'STATUS_UPDATE':
                this.addNotification(`✈ ${msg.flight_number}: ${msg.status}`);
                this.loadFlights();
                break;
            case 'SHUTDOWN':
                this.error = 'Server is shutting down.';
                break;
            case 'KILLED':
                this.error = msg.message;
                break;
            case 'ERROR':
                this.error = msg.message;
                setTimeout(() => { this.error = ''; }, 4000);
                break;
        }
    }

    private addNotification(msg: string): void {
        this.notifications.unshift(msg);
        if (this.notifications.length > 20) this.notifications.pop();
    }

    async loadFlights(): Promise<void> {
        const user = this.auth.user;
        if (!user) return;
        try {
            const res = await fetch(this.API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: 'GetAllFlights', apikey: user.apikey })
            });
            const json = await res.json();
            if (json.status === 'success') this.flights = json.data || [];
        } catch { this.error = 'Could not load flights.'; }
    }

    async loadAirports(): Promise<void> {
        const user = this.auth.user;
        if (!user) return;
        try {
            const res = await fetch(this.API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: 'GetAirports', apikey: user.apikey })
            });
            const json = await res.json();
            if (json.status === 'success') this.airports = json.data || [];
        } catch { }
    }

    async selectFlight(flight: any): Promise<void> {
        this.selectedFlight = flight;
        this.position = null;
        const user = this.auth.user;
        if (!user) return;
        try {
            const res = await fetch(this.API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: 'GetFlight', apikey: user.apikey, flight_id: flight.id })
            });
            const json = await res.json();
            if (json.status === 'success') this.flightDetail = json.data[0];
        } catch { }
    }

    private async refreshDetail(): Promise<void> {
        if (this.selectedFlight) this.selectFlight(this.selectedFlight);
    }

    dispatchFlight(): void {
        if (!this.selectedFlight || !this.connected) return;
        this.ws.send({ type: 'DISPATCH', flight_id: this.selectedFlight.id });
    }

    trackFlight(): void {
        if (!this.selectedFlight || !this.connected) return;
        this.ws.send({ type: 'TRACK', flight_id: this.selectedFlight.id });
    }

    logout(): void {
        this.ws.disconnect();
        this.auth.logout();
    }

    ngOnDestroy(): void {
        this.sub?.unsubscribe();
        this.connSub?.unsubscribe();
    }
}