// Names: MAHIKA, DEON, TAUHIR
// Surnames: LALA, STEENKAMP, SEPTEMBER
// Student Numbers: 25013727, 25135742, 24750982

import { Component, OnInit, OnDestroy, Input, OnChanges, SimpleChanges } from '@angular/core';
import * as L from 'leaflet';

@Component({
    selector: 'app-map',
    templateUrl: './map.component.html',
    styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit, OnDestroy, OnChanges {
    @Input() airports: any[] = [];
    @Input() position: any = null; // { latitude, longitude, flight_number, progress, status }

    private map!: L.Map;
    private planeMarker: L.Marker | null = null;
    private airportMarkers: L.LayerGroup = L.layerGroup();

    private airportIcon = L.divIcon({
        className: '',
        html: '<div style="background:#4a9eff;border:2px solid #fff;border-radius:50%;width:10px;height:10px;box-shadow:0 0 6px rgba(74,158,255,0.8)"></div>',
        iconSize: [10, 10],
        iconAnchor: [5, 5]
    });

    private planeIcon = L.divIcon({
        className: '',
        html: '<div style="font-size:22px;transform:rotate(0deg);filter:drop-shadow(0 0 6px rgba(255,200,0,0.9))">✈</div>',
        iconSize: [22, 22],
        iconAnchor: [11, 11]
    });

    ngOnInit(): void {
        this.map = L.map('map', { center: [20, 0], zoom: 2 });
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(this.map);
        this.airportMarkers.addTo(this.map);
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['airports'] && this.map) this.plotAirports();
        if (changes['position'] && this.map && this.position) this.updatePlane();
    }

    private plotAirports(): void {
        this.airportMarkers.clearLayers();
        for (const a of this.airports) {
            const lat = parseFloat(a.latitude);
            const lng = parseFloat(a.longitude);
            if (isNaN(lat) || isNaN(lng)) continue;
            const marker = L.marker([lat, lng], { icon: this.airportIcon });
            marker.bindTooltip(`${a.name} (${a.iata_code})<br>${a.city}, ${a.country}`, { direction: 'top' });
            this.airportMarkers.addLayer(marker);
        }
    }

    private updatePlane(): void {
        const lat = parseFloat(this.position.latitude);
        const lng = parseFloat(this.position.longitude);
        if (isNaN(lat) || isNaN(lng)) return;

        if (!this.planeMarker) {
            this.planeMarker = L.marker([lat, lng], { icon: this.planeIcon }).addTo(this.map);
        } else {
            this.planeMarker.setLatLng([lat, lng]);
        }
        this.planeMarker.bindTooltip(
            `✈ ${this.position.flight_number || ''}<br>Progress: ${this.position.progress}%<br>Status: ${this.position.status}`,
            { direction: 'top', permanent: false }
        );
    }

    removePlane(): void {
        if (this.planeMarker) {
            this.planeMarker.remove();
            this.planeMarker = null;
        }
    }

    ngOnDestroy(): void {
        this.map?.remove();
    }
}