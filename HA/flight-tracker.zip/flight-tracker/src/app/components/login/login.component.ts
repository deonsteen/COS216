// Names: MAHIKA, DEON, TAUHIR
// Surnames: LALA, STEENKAMP, SEPTEMBER
// Student Numbers: 25013727, 25135742, 24750982

import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { WebsocketService } from '../../services/websocket.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent {
    email = '';
    password = '';
    port = 8080;
    error = '';
    loading = false;

    constructor(private auth: AuthService, private ws: WebsocketService) { }

    async onLogin() {
        this.error = '';
        this.loading = true;
        try {
            const user = await this.auth.login(this.email, this.password);
            // Connect WebSocket then authenticate
            this.ws.connect(this.port);
            // Wait briefly for connection then send AUTH
            setTimeout(() => {
                this.ws.send({
                    type: 'AUTH',
                    apikey: user.apikey,
                    email: this.email,
                    password: this.password,
                    role: user.type,
                    username: user.username
                });
            }, 600);
        } catch (err: any) {
            this.error = err.message || 'Login failed. Check credentials.';
        } finally {
            this.loading = false;
        }
    }
}