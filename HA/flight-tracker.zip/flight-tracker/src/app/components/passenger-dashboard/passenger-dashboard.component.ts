// Names: MAHIKA, DEON, TAUHIR
// Surnames: LALA, STEENKAMP, SEPTEMBER
// Student Numbers: 25013727, 25135742, 24750982

import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { WebsocketService } from '../../services/websocket.service';

@Component({
    selector: 'app-passenger-dashboard',
    templateUrl: './passenger-dashboard.component.html',
    styleUrls: ['./passenger-dashboard.component.css']
})
export class PassengerDashboardComponent implements OnInit, OnDestroy {
    flights: any[] = [];
    airports: any[] = [];
    trackedFlight: any = null;
    position: any = null;
    boardingCall: any = null;   // { flight_id, flight_number, message }
    countdown = 0;
    private countdownInterval: any = null;
    notification = '';
    error = '';
    connected = false;

    private API = 'https://u25013727:Elephant%40130206@wheatley.cs.up.ac.za/u25013727/api.php';
    private sub!: Subscription;
    private connSub!: Subscription;

    constructor(public auth: AuthService, private ws: WebsocketService) { }

    ngOnInit(): void {
        this.connSub = this.ws.connected$.subscribe(c => { this.connected = c; });
        this.sub = this.ws.messages$.subscribe(msg => this.handleMessage(msg));
        this.loadFlights();
        this.loadAirports();
    }

    private handleMessage(msg: any): void {
        switch (msg.type) {
            case 'BOARDING_CALL':
                this.boardingCall = msg;
                this.startCountdown();
                this.notify(`Your flight ${msg.flight_number} is now boarding!`);
                break;
            case 'POSITION':
                this.position = msg;
                break;
            case 'TRACK_OK':
                this.notify(msg.message);
                break;
            case 'BOARD_OK':
                this.notify('Boarding confirmed!');
                this.boardingCall = null;
                this.stopCountdown();
                break;
            case 'FLIGHT_LANDED':
                this.notify(`Flight ${msg.flight_number} has landed!`);
                this.position = null;
                break;
            case 'STATUS_UPDATE':
                this.notify(`Flight ${msg.flight_number}: ${msg.status}`);
                this.loadFlights();
                break;
            case 'ATC_DISCONNECTED':
                this.notify(msg.message);
                break;
            case 'SHUTDOWN':
                this.error = 'Server is shutting down. Please reconnect later.';
                break;
            case 'KILLED':
                this.error = msg.message;
                break;
            case 'ERROR':
                this.error = msg.message;
                break;
        }
    }

    private startCountdown(): void {
        this.countdown = 60;
        this.stopCountdown();
        this.countdownInterval = setInterval(() => {
            this.countdown--;
            if (this.countdown <= 0) {
                this.stopCountdown();
                if (this.boardingCall) {
                    this.boardingCall = null;
                    this.notify('Boarding window expired. You have been marked as a no-show.');
                }
            }
        }, 1000);
    }

    private stopCountdown(): void {
        if (this.countdownInterval) { clearInterval(this.countdownInterval); this.countdownInterval = null; }
    }

    private notify(msg: string): void {
        this.notification = msg;
        setTimeout(() => { if (this.notification === msg) this.notification = ''; }, 5000);
    }

    async loadFlights(): Promise<void> {
        const user = this.auth.user;
        if (!user) return;
        try {
            const res = await fetch(this.API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: 'GetAllFlights', apikey: user.apikey })
            });
            const json = await res.json();
            if (json.status === 'success') this.flights = json.data || [];
        } catch { this.error = 'Could not load flights.'; }
    }

    async loadAirports(): Promise<void> {
        const user = this.auth.user;
        if (!user) return;
        try {
            const res = await fetch(this.API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: 'GetAirports', apikey: user.apikey })
            });
            const json = await res.json();
            if (json.status === 'success') this.airports = json.data || [];
        } catch { }
    }

    trackFlight(flight: any): void {
        this.trackedFlight = flight;
        this.position = null;
        this.ws.send({ type: 'TRACK', flight_id: flight.id });
    }

    confirmBoarding(): void {
        if (!this.boardingCall) return;
        this.ws.send({ type: 'BOARD', flight_id: this.boardingCall.flight_id });
    }

    logout(): void {
        this.ws.disconnect();
        this.auth.logout();
    }

    ngOnDestroy(): void {
        this.sub?.unsubscribe();
        this.connSub?.unsubscribe();
        this.stopCountdown();
    }
}