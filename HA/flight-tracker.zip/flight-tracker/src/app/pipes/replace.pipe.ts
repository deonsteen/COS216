// Names: MAHIKA, DEON, TAUHIR
// Surnames: LALA, STEENKAMP, SEPTEMBER
// Student Numbers: 25013727, 25135742, 24750982

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'replace' })
export class ReplacePipe implements PipeTransform {
    transform(value: string, from: string, to: string): string {
        return value ? value.split(from).join(to) : value;
    }
}
