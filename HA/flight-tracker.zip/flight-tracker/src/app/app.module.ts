// Names: MAHIKA, DEON, TAUHIR
// Surnames: LALA, STEENKAMP, SEPTEMBER
// Student Numbers: 25013727, 25135742, 24750982

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { AtcDashboardComponent } from './components/atc-dashboard/atc-dashboard.component';
import { PassengerDashboardComponent } from './components/passenger-dashboard/passenger-dashboard.component';
import { MapComponent } from './components/map/map.component';
import { ReplacePipe } from './pipes/replace.pipe';

@NgModule({
    declarations: [
        AppComponent,
        LoginComponent,
        AtcDashboardComponent,
        PassengerDashboardComponent,
        MapComponent,
        ReplacePipe
    ],
    imports: [BrowserModule, AppRoutingModule, FormsModule],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }
